# Introduction 
This folder contains the scripts to AdjustVMproperties
    
    -CPU
    -MEM
    -Create/Remove/Revert snapshots

To be added

    -New Harddisk
    -Disk extensions
 